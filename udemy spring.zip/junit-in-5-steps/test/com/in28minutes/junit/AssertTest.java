package com.in28minutes.junit;

import static org.junit.Assert.*;

import org.junit.Test;

public class AssertTest {

	@Test
	public void test() {
		assertEquals(true, true);
		boolean condn = false;
		assertTrue(condn);	
		assertFalse(condn);
		
	}

}
